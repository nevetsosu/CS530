Just make and run.

Disk access counts are a known issue.
