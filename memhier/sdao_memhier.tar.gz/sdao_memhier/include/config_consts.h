#define TLB_MAX_SETS        256lu
#define DC_MAX_SETS         8192lu
#define MAX_ASSOCIATIVITY   8lu
#define NUM_VPAGES_MAX      8192lu
#define NUM_PPAGES_MAX      1024lu
#define MAX_ADDR_LEN        32lu
#define MIN_LINE_SIZE       8lu
